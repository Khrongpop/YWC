<template>
  <div class="mt-4">
    <p class="footer"> Copyright © 2018 Khrongpop Phonngam. All Rights Reserved.</p>
  </div>
</template>

<style scope>
.footer {
  text-align: center;
  line-height: 2;
  background-color: #222;
  color: #fff;
  margin-bottom: 0;
  padding: 10px 0;
}
</style>
